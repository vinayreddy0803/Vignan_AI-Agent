'use client'

import { GraduationCap, BookOpen, Code, Lightbulb, FileText } from 'lucide-react'

interface WelcomeScreenProps {
  onSuggestionClick: (suggestion: string) => void
}

const suggestions = [
  {
    icon: BookOpen,
    title: 'Academic Help',
    description: 'Explain the concept of machine learning',
  },
  {
    icon: Code,
    title: 'Coding Assistant',
    description: 'Write a Python function to sort an array',
  },
  {
    icon: Lightbulb,
    title: 'Research Ideas',
    description: 'Suggest research topics in AI and healthcare',
  },
  {
    icon: FileText,
    title: 'Writing Help',
    description: 'Help me write an abstract for my paper',
  },
]

export function WelcomeScreen({ onSuggestionClick }: WelcomeScreenProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 md:p-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center mx-auto mb-4">
          <GraduationCap className="w-8 h-8 text-primary-foreground" />
        </div>
        <h1 className="text-2xl md:text-3xl font-semibold text-foreground mb-2">
          Welcome to VIGNAN AI
        </h1>
        <p className="text-muted-foreground max-w-md">
          Your intelligent assistant for academic excellence at Vignan&apos;s University
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl">
        {suggestions.map((suggestion) => (
          <button
            key={suggestion.title}
            onClick={() => onSuggestionClick(suggestion.description)}
            className="flex items-start gap-3 p-4 rounded-xl bg-card border border-border hover:border-primary/50 hover:bg-card/80 transition-all text-left group"
          >
            <div className="w-9 h-9 rounded-lg bg-secondary flex items-center justify-center shrink-0 group-hover:bg-primary/10 transition-colors">
              <suggestion.icon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
            </div>
            <div>
              <h3 className="font-medium text-sm text-foreground mb-0.5">
                {suggestion.title}
              </h3>
              <p className="text-xs text-muted-foreground">
                {suggestion.description}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
