import { NextResponse } from 'next/server'

// Simple rule-based AI agent for Vignan University
class VignanAIAgent {
  private responses: { [key: string]: string[] } = {
    greeting: [
      "Hello! I'm VIGNAN AI, your intelligent assistant for Vignan University. How can I help you today?",
      "Welcome to Vignan University! I'm here to assist you with any questions about academics, campus life, or university services.",
      "Hi there! I'm VIGNAN AI, ready to help you navigate your journey at Vignan University."
    ],

    courses: [
      "Vignan University offers a comprehensive range of undergraduate and postgraduate programs:\n\n**🏫 Engineering Programs:**\n• Computer Science & Engineering (CSE)\n• Electrical & Electronics Engineering (EEE)\n• Electronics & Communication Engineering (ECE)\n• Mechanical Engineering (ME)\n• Civil Engineering (CE)\n• Information Technology (IT)\n\n**💼 Management Programs:**\n• Master of Business Administration (MBA)\n• Bachelor of Business Administration (BBA)\n\n**🔬 Science Programs:**\n• B.Sc, M.Sc in Mathematics, Physics, Chemistry, Biotechnology\n\n**📚 Humanities:**\n• BA, MA in English, Psychology, Sociology\n\nEach program includes industry-relevant curriculum, practical training, and placement assistance. Would you like details about any specific course?",
      "Our academic offerings are designed to meet industry standards and global requirements. We have:\n\n**Undergraduate Programs:** 4-year B.Tech/B.Sc/BBA degrees\n**Postgraduate Programs:** 2-year M.Tech/MBA/M.Sc degrees\n**Research Programs:** Ph.D. in various disciplines\n\n**Special Features:**\n• Industry-integrated curriculum\n• International collaborations\n• Research opportunities\n• Entrepreneurship development\n• Skill enhancement programs\n\nAll programs are approved by UGC and affiliated to JNTUK."
    ],

    admissions: [
      "For admissions at Vignan University:\n\n**Eligibility:**\n• 10+2 with minimum 60% for UG programs\n• Bachelor's degree for PG programs\n\n**Entrance Exams:**\n• EAMCET for Engineering\n• ICET for MBA\n• Direct admission based on merit\n\n**Application Process:**\n1. Visit our website\n2. Fill online application\n3. Submit required documents\n4. Pay application fee\n\nContact admissions office for personalized guidance!",
      "Admission season is typically from March to June. We offer multiple entry points throughout the year. Scholarships are available for meritorious students. Visit our admissions portal for detailed requirements."
    ],

    facilities: [
      "Vignan University boasts state-of-the-art facilities:\n\n🏫 **Academic Buildings:** Modern classrooms with smart boards\n📚 **Libraries:** Digital and physical collections\n💻 **Computer Labs:** Latest hardware and software\n⚽ **Sports Complex:** Indoor and outdoor facilities\n🏢 **Hostels:** Separate for boys and girls\n🍽️ **Cafeteria:** Multiple dining options\n🏥 **Medical Center:** 24/7 healthcare services\n\nAll facilities are designed to enhance your learning experience.",
      "Our campus spans over 100 acres with:\n• Wi-Fi enabled campus\n• Research centers and labs\n• Auditorium and seminar halls\n• Banking and postal services\n• Transportation services\n• Gymnasium and fitness centers\n\nSafety and security are our top priorities with 24/7 surveillance."
    ],

    placements: [
      "Vignan University has established itself as a premier institution for placements:\n\n**📊 Placement Statistics (2023-24):**\n• **Placement Rate:** 98%\n• **Highest Package:** ₹52 LPA (Amazon)\n• **Average Package:** ₹7.2 LPA\n• **Median Package:** ₹6.8 LPA\n\n**🏢 Top Recruiters:**\n• **Tech Giants:** Google, Microsoft, Amazon, Meta, Adobe\n• **IT Companies:** TCS, Infosys, Wipro, Cognizant, Deloitte\n• **Core Companies:** Tata Steel, L&T, Reliance, Adani Group\n• **Consulting:** EY, PwC, KPMG, Accenture\n• **Startups:** Paytm, Ola, Swiggy, Zomato\n\n**🎯 Placement Process:**\n• Pre-placement talks and workshops\n• Aptitude training and mock interviews\n• Resume building and soft skills training\n• Industry interaction sessions\n• Career counseling and guidance\n\n**📈 Year-wise Growth:**\n• 2022-23: 96% placement rate\n• 2023-24: 98% placement rate\n• Consistent improvement in packages\n\n**🌍 International Placements:**\n• Students placed in USA, UK, Canada, Australia\n• Global internship opportunities\n\nOur dedicated placement cell works year-round to ensure every student gets the best career opportunities.",
      "Our placement record speaks for our quality education and industry relevance:\n\n**🏆 Achievements:**\n• 500+ companies visit annually\n• 10,000+ placement offers\n• 50+ companies offering above ₹10 LPA\n• International placement opportunities\n\n**📚 Training Programs:**\n• Technical skill development\n• Communication and soft skills\n• Aptitude and reasoning training\n• Mock interviews and GD sessions\n• Industry-specific training\n\n**🤝 Industry Partnerships:**\n• Campus recruitment drives\n• Internship programs\n• Guest lectures by industry experts\n• Industry-academia collaboration\n• Joint certification programs\n\n**📊 Department-wise Placements:**\n• CSE: 99% placement rate\n• ECE/EEE: 97% placement rate\n• ME/CE: 95% placement rate\n• MBA: 96% placement rate"
    ],

    research: [
      "Vignan University encourages research and innovation:\n\n🔬 **Research Centers:**\n• Center for Advanced Computing\n• Innovation and Entrepreneurship Hub\n• Material Science Research Lab\n• Biotechnology Research Center\n\n📝 **Publications:** Regular papers in reputed journals\n🎯 **Projects:** Industry-sponsored research\n🌍 **Collaborations:** International partnerships\n\nStudents can participate in:\n• Research internships\n• Conference presentations\n• Patent filings\n• Startup incubation",
      "We have multiple research groups working on cutting-edge technologies. Our faculty members have published extensively in areas like AI, IoT, Renewable Energy, and Biotechnology. Students are encouraged to join research projects from their second year onwards."
    ],

    coding: [
      "Vignan University offers excellent coding resources:\n\n💻 **Programming Languages:** Python, Java, C++, JavaScript\n🌐 **Web Development:** HTML, CSS, React, Node.js\n🤖 **AI/ML:** TensorFlow, PyTorch, Scikit-learn\n📱 **Mobile Development:** Android, iOS, Flutter\n\n**Learning Resources:**\n• Coding clubs and hackathons\n• Online platforms (LeetCode, HackerRank)\n• Industry certifications\n• Project-based learning\n\nOur CSE department has specialized labs for each technology stack.",
      "We have a strong focus on practical coding skills. Students participate in coding competitions, hackathons, and real-world projects. Our curriculum includes data structures, algorithms, and modern frameworks. Many students have won national-level coding competitions."
    ],

    hostel: [
      "Vignan University provides comfortable hostel facilities:\n\n🏢 **Hostel Types:**\n• Boys' Hostel (4 blocks)\n• Girls' Hostel (2 blocks)\n• International Students' Hostel\n\n✨ **Amenities:**\n• AC and Non-AC rooms\n• 24/7 security\n• Wi-Fi connectivity\n• Laundry services\n• Mess facilities\n• Study rooms\n• Recreation areas\n\n**Fees:** Starting from ₹85,000 per year\n**Capacity:** 3000+ students\n\nHostels are located within the campus for easy access to academic buildings.",
      "Our hostels are designed to feel like home away from home. Each room accommodates 2-3 students with attached bathrooms. We have round-the-clock security, housekeeping, and maintenance services. The mess provides nutritious meals with vegetarian and non-vegetarian options."
    ],

    fees: [
      "Vignan University offers competitive fee structures with various payment options:\n\n**💰 Engineering Programs (B.Tech):**\n• **Tuition Fee:** ₹1.2-1.5 lakhs per year\n• **Development Fee:** ₹25,000-35,000 per year\n• **Other Fees:** ₹15,000-20,000 per year\n• **Total:** ₹1.6-2 lakhs per year\n\n**💼 Management Programs (MBA/BBA):**\n• **Tuition Fee:** ₹1.5-2 lakhs per year\n• **Development Fee:** ₹30,000-40,000 per year\n• **Other Fees:** ₹20,000-25,000 per year\n• **Total:** ₹1.95-2.65 lakhs per year\n\n**🔬 Science Programs (B.Sc/M.Sc):**\n• **Tuition Fee:** ₹80,000-1.2 lakhs per year\n• **Development Fee:** ₹20,000-30,000 per year\n• **Other Fees:** ₹15,000-20,000 per year\n• **Total:** ₹1.15-1.7 lakhs per year\n\n**📚 Humanities Programs:**\n• **Tuition Fee:** ₹60,000-90,000 per year\n• **Development Fee:** ₹15,000-25,000 per year\n• **Other Fees:** ₹10,000-15,000 per year\n• **Total:** ₹85,000-1.3 lakhs per year\n\n**🎓 Additional Costs:**\n• **Hostel Fee:** ₹85,000-1.5 lakhs per year\n• **Transportation:** ₹15,000-25,000 per year\n• **Books & Study Materials:** ₹10,000-15,000 per year\n• **Medical Insurance:** ₹2,000-3,000 per year\n\n**💳 Payment Options:**\n• Full payment at admission\n• Semester-wise payment\n• Online payment gateway\n• Bank loan assistance available\n\n**🎁 Scholarships & Financial Aid:**\n• **Merit Scholarships:** Up to 100% tuition waiver\n• **Sports Scholarships:** For outstanding athletes\n• **Need-based Aid:** For economically weaker students\n• **Research Scholarships:** For Ph.D. scholars\n• **Alumni Scholarships:** For family members\n\n**📊 Scholarship Categories:**\n• **Category A:** 90%+ marks → 50% waiver\n• **Category B:** 80-89% marks → 30% waiver\n• **Category C:** 70-79% marks → 20% waiver\n• **Category D:** 60-69% marks → 10% waiver\n\n**🏦 Education Loan Assistance:**\n• Tie-up with major banks (SBI, HDFC, ICICI)\n• Easy loan approval process\n• Flexible repayment options\n• Interest subsidy available\n\n**📞 Fee-related Queries:**\n• Contact: +91-863-2344-703\n• Email: fees@vignanuniversity.org\n• Visit: Administrative Block, Room 101",
      "Our fee structure is designed to be affordable while maintaining world-class education standards:\n\n**💰 Payment Schedule:**\n• **At Admission:** 50% of annual fees\n• **Semester 1 End:** 25% of annual fees\n• **Semester 2 Start:** 25% of annual fees\n\n**📋 Refund Policy:**\n• **Within 7 days:** 90% refund\n• **Within 15 days:** 75% refund\n• **Within 30 days:** 50% refund\n• **After 30 days:** No refund\n\n**🎯 Fee Concessions:**\n• SC/ST students: Government scholarships\n• Single girl child: Additional concessions\n• Defense personnel wards: Special discounts\n• Faculty wards: Reduced fees\n\n**📊 Fee Comparison:**\n• Vignan fees are 20-30% lower than similar private universities\n• Best value for money in Andhra Pradesh\n• Quality education at affordable prices"
    ],

    default: [
      "I'm here to help you with information about Vignan University. You can ask me about:\n\n• Academic programs and courses\n• Admission procedures\n• Campus facilities\n• Placement opportunities\n• Research activities\n• Hostel and accommodation\n• Fee structure\n• Coding and technical resources\n\nWhat specific information are you looking for?",
      "As VIGNAN AI, I can assist you with various aspects of university life. Feel free to ask about courses, admissions, facilities, placements, research, or any other university-related queries. How can I help you today?",
      "I'm your AI assistant for Vignan University. I have information about our academic programs, campus facilities, admission process, and much more. What would you like to know?"
    ]
  }

  private getResponseType(message: string): string {
    const lowerMessage = message.toLowerCase()

    // Check for keywords and return appropriate response type
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
      return 'greeting'
    }
    if (lowerMessage.includes('course') || lowerMessage.includes('program') || lowerMessage.includes('subject') || lowerMessage.includes('study')) {
      return 'courses'
    }
    if (lowerMessage.includes('admission') || lowerMessage.includes('admit') || lowerMessage.includes('join') || lowerMessage.includes('apply')) {
      return 'admissions'
    }
    if (lowerMessage.includes('facility') || lowerMessage.includes('campus') || lowerMessage.includes('building') || lowerMessage.includes('infrastructure')) {
      return 'facilities'
    }
    if (lowerMessage.includes('placement') || lowerMessage.includes('job') || lowerMessage.includes('career') || lowerMessage.includes('recruit')) {
      return 'placements'
    }
    if (lowerMessage.includes('research') || lowerMessage.includes('project') || lowerMessage.includes('publication') || lowerMessage.includes('innovation')) {
      return 'research'
    }
    if (lowerMessage.includes('code') || lowerMessage.includes('programming') || lowerMessage.includes('develop') || lowerMessage.includes('software')) {
      return 'coding'
    }
    if (lowerMessage.includes('hostel') || lowerMessage.includes('accommodation') || lowerMessage.includes('stay') || lowerMessage.includes('room')) {
      return 'hostel'
    }
    if (lowerMessage.includes('fee') || lowerMessage.includes('cost') || lowerMessage.includes('price') || lowerMessage.includes('payment') || lowerMessage.includes('money')) {
      return 'fees'
    }

    return 'default'
  }

  public generateResponse(message: string): string {
    const responseType = this.getResponseType(message)
    const possibleResponses = this.responses[responseType] || this.responses.default

    // Return a random response from the category
    return possibleResponses[Math.floor(Math.random() * possibleResponses.length)]
  }
}

// Create a singleton instance
const vignanAI = new VignanAIAgent()

export async function POST(req: Request) {
  try {
    const { messages }: { messages: any[] } = await req.json()

    // Get the last user message
    const lastMessage = messages[messages.length - 1]
    const userMessage = lastMessage?.parts?.find((p: any) => p.type === 'text')?.text || ''

    // Generate response using our local AI agent
    const aiResponse = vignanAI.generateResponse(userMessage)

    // Create a streaming response
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      start(controller) {
        // Simulate streaming by sending the response in chunks
        const words = aiResponse.split(' ')
        let index = 0

        const sendNextWord = () => {
          if (index < words.length) {
            const word = words[index] + ' '
            controller.enqueue(encoder.encode(`0:${JSON.stringify({ text: word })}\n`))
            index++
            setTimeout(sendNextWord, 50) // Small delay to simulate streaming
          } else {
            controller.enqueue(encoder.encode('e:{"finishReason":"stop"}\n'))
            controller.close()
          }
        }

        sendNextWord()
      }
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'X-Experimental-Stream-Data': 'true'
      }
    })

  } catch (error) {
    console.error('Error in chat API:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
