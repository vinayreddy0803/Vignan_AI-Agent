'use client'

import { useState, useRef, useEffect } from 'react'
import { Menu, PanelLeftClose, Settings, User, Upload } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ThemeToggle } from '@/components/theme-toggle'
import { ChatSidebar } from '@/components/chat/chat-sidebar'
import { ChatMessage } from '@/components/chat/chat-message'
import { ChatInput } from '@/components/chat/chat-input'
import { WelcomeScreen } from '@/components/chat/welcome-screen'
import Link from 'next/link'

export default function VignanAIChat() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [input, setInput] = useState('')
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [messages, setMessages] = useState<Array<{id: string, role: 'user' | 'assistant', parts: Array<{type: 'text', text: string}>}>>([])
  const [isLoading, setIsLoading] = useState(false)
  const [chatHistory, setChatHistory] = useState<Array<{id: string, title: string, date: string, messages: any[]}>>([])
  const [activeChatId, setActiveChatId] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const handleSubmit = async () => {
    if (!input.trim() || isLoading) return

    const userMessage = {
      id: Date.now().toString(),
      role: 'user' as const,
      parts: [{ type: 'text' as const, text: input }]
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [...messages, userMessage]
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to get response')
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let aiResponse = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value)
          const lines = chunk.split('\n')

          for (const line of lines) {
            if (line.startsWith('0:')) {
              try {
                const data = JSON.parse(line.slice(2))
                if (data.text) {
                  aiResponse += data.text
                }
              } catch (e) {
                // Ignore parsing errors
              }
            }
          }
        }
      }

      const aiMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant' as const,
        parts: [{ type: 'text' as const, text: aiResponse }]
      }

      setMessages(prev => [...prev, aiMessage])

      // Removed automatic speaking - users can manually trigger voice output if needed

    } catch (error) {
      console.error('Error sending message:', error)
      const errorMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant' as const,
        parts: [{ type: 'text' as const, text: 'Sorry, I encountered an error. Please try again.' }]
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleNewChat = () => {
    // Save current chat to history if it has messages
    if (messages.length > 0) {
      const chatTitle = messages[0]?.parts?.find((p): p is { type: 'text'; text: string } => p.type === 'text')?.text?.slice(0, 30) + '...' || 'New Chat'
      const newChat = {
        id: Date.now().toString(),
        title: chatTitle,
        date: new Date().toLocaleDateString(),
        messages: [...messages]
      }
      setChatHistory(prev => [newChat, ...prev])
    }

    // Clear current chat
    setMessages([])
    setInput('')
    setUploadedFiles([])
    setActiveChatId(null)
  }

  const handleSelectChat = (chatId: string) => {
    const selectedChat = chatHistory.find(chat => chat.id === chatId)
    if (selectedChat) {
      setMessages(selectedChat.messages)
      setActiveChatId(chatId)
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion)
  }

  const handleFileUpload = (file: File) => {
    setUploadedFiles(prev => [...prev, file])
    // Here you could send the file to your API or process it
    console.log('File uploaded:', file.name)
  }

  // Generate chat history for sidebar display
  const sidebarChatHistory = chatHistory.map(chat => ({
    id: chat.id,
    title: chat.title,
    date: chat.date
  }))

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <ChatSidebar
        isOpen={sidebarOpen}
        onNewChat={handleNewChat}
        chatHistory={sidebarChatHistory}
        activeChatId={activeChatId}
        onSelectChat={handleSelectChat}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-14 border-b border-border flex items-center justify-between px-4 bg-background/80 backdrop-blur-sm">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="mr-2"
            >
              {sidebarOpen ? (
                <PanelLeftClose className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </Button>
            <h2 className="font-semibold text-foreground">VIGNAN AI</h2>
            <span className="ml-2 text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
              Beta
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Link href="/settings">
              <Button variant="ghost" size="icon" title="Settings">
                <Settings className="w-5 h-5" />
              </Button>
            </Link>
            <Link href="/profile">
              <Button variant="ghost" size="icon" title="Profile">
                <User className="w-5 h-5" />
              </Button>
            </Link>
            <ThemeToggle />
          </div>
        </header>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto">
          {messages.length === 0 ? (
            <WelcomeScreen onSuggestionClick={handleSuggestionClick} />
          ) : (
            <div className="pb-4">
              {messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))}
              {isLoading && messages[messages.length - 1]?.role === 'user' && (
                <div className="py-6 px-4 md:px-0 bg-card/30">
                  <div className="max-w-3xl mx-auto flex gap-4">
                    <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                      <div className="w-4 h-4 flex items-center justify-center">
                        <div className="flex gap-1">
                          <span className="w-1.5 h-1.5 bg-primary-foreground rounded-full animate-bounce [animation-delay:-0.3s]" />
                          <span className="w-1.5 h-1.5 bg-primary-foreground rounded-full animate-bounce [animation-delay:-0.15s]" />
                          <span className="w-1.5 h-1.5 bg-primary-foreground rounded-full animate-bounce" />
                        </div>
                      </div>
                    </div>
                    <div className="flex-1">
                      <span className="font-medium text-sm text-foreground">VIGNAN AI</span>
                      <p className="text-muted-foreground mt-1">Thinking...</p>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <ChatInput
          value={input}
          onChange={setInput}
          onSubmit={handleSubmit}
          onFileUpload={handleFileUpload}
          isLoading={isLoading}
        />
      </div>
    </div>
  )
}
